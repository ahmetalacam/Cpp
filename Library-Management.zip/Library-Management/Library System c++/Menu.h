#ifndef MENU_H
#define MENU_H

#include <iostream>
#include<fstream>
#include<conio.h>
#include<stdio.h>
#include<process.h>
#include<string.h>
#include<iomanip>
using namespace std;

class Menu{
	public:
		void Introduction();
		void Admin();
};
#endif
