#ifndef USER_H
#define USER_H
#include <string>

using namespace std;

class User{
	
	public:
		void login() const;
		void registr() const;
			
};
#endif
